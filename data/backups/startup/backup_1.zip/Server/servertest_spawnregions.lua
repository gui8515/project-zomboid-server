function SpawnRegions()
	return {
		{ name = "1. Muldraugh - Ideal para iniciantes", file = "media/maps/Muldraugh, KY/spawnpoints.lua" },
		{ name = "2. Riverside - Bom loot e zumbis equilibrados", file = "media/maps/Riverside, KY/spawnpoints.lua" },
		{ name = "3. Rosewood - Bom loot e zumbis equilibrados", file = "media/maps/Rosewood, KY/spawnpoints.lua" },
		{ name = "4. West Point - Mais loot, mas muitos zumbis", file = "media/maps/West Point, KY/spawnpoints.lua" },
		{ name = "5. Aleat�rio - Loot variado e zumbis Imprevis�veis", file = "media/maps/Pillows All Spawns No LV/spawnpoints.lua" },
	}
end
