Backup time: 2025-11-03 at 22:18:47 UTC
ServerName: servertest
Current server version:41.78
Current world version:195
World version in this backup is:195