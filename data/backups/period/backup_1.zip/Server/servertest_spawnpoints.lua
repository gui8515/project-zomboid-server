function SpawnPoints()
	return {
		unemployed = {
			{ worldX = 40, worldY = 22, posX = 67, posY = 201, posZ = 0 },
		},
	}
end
